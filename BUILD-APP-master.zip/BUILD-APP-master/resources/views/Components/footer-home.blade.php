<footer>
    <div style="background-color: yellow;" class="text-center">
        <h2>BUILD APP</h2>
    </div>
  </footer>
